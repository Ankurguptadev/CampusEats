require('dotenv').config();

const { ApolloServer } = require('@apollo/server');
const { startStandaloneServer } = require('@apollo/server/standalone');
const pool = require('./db');

const typeDefs = `#graphql
  type Author {
    id: ID!
    name: String!
    country: String
    books: [Book!]!
  }

  type Book {
    id: ID!
    title: String!
    year: Int
    author: Author!
  }

  type Query {
    authors: [Author!]!
    author(id: ID!): Author
    books: [Book!]!
  }

  type Mutation {
    addBook(
      title: String!
      year: Int
      authorName: String!
    ): Book!
  }
`;

const resolvers = {
  Query: {
    authors: async () => {
      const [rows] = await pool.query('SELECT * FROM authors ORDER BY id');
      return rows;
    },

    author: async (_parent, { id }) => {
      const [rows] = await pool.query(
        'SELECT * FROM authors WHERE id = ?',
        [id]
      );
      return rows[0] || null;
    },

    books: async () => {
      const [rows] = await pool.query('SELECT * FROM books ORDER BY id');
      return rows;
    }
  },

  Author: {
    books: async (author) => {
      const [rows] = await pool.query(
        'SELECT * FROM books WHERE author_id = ? ORDER BY id',
        [author.id]
      );
      return rows;
    }
  },

  Book: {
    author: async (book) => {
      const [rows] = await pool.query(
        'SELECT * FROM authors WHERE id = ?',
        [book.author_id]
      );
      return rows[0] || null;
    }
  },

  Mutation: {
    addBook: async (_parent, { title, year, authorName }) => {
      const cleanTitle = title.trim();
      const cleanAuthorName = authorName.trim();

      if (!cleanTitle) {
        throw new Error('Book title cannot be empty.');
      }
      if (!cleanAuthorName) {
        throw new Error('Author name cannot be empty.');
      }
      if (year !== null && year !== undefined &&
          (!Number.isInteger(year) || year < 0 || year > 2100)) {
        throw new Error('Please provide a valid publication year.');
      }

      const [existingAuthors] = await pool.query(
        'SELECT * FROM authors WHERE LOWER(name) = LOWER(?) LIMIT 1',
        [cleanAuthorName]
      );

      let authorId;

      if (existingAuthors.length > 0) {
        authorId = existingAuthors[0].id;
      } else {
        const [authorResult] = await pool.query(
          'INSERT INTO authors (name, country) VALUES (?, ?)',
          [cleanAuthorName, null]
        );
        authorId = authorResult.insertId;
      }

      const [bookResult] = await pool.query(
        'INSERT INTO books (title, year, author_id) VALUES (?, ?, ?)',
        [cleanTitle, year ?? null, authorId]
      );

      const [newBooks] = await pool.query(
        'SELECT * FROM books WHERE id = ?',
        [bookResult.insertId]
      );

      return newBooks[0];
    }
  }
};

async function start() {
  const server = new ApolloServer({ typeDefs, resolvers });
  const port = Number(process.env.PORT || 3000);

  const { url } = await startStandaloneServer(server, {
    listen: { port }
  });

  console.log(`GraphQL API ready at ${url}`);
}

start().catch((error) => {
  console.error('Failed to start GraphQL server:', error);
  process.exit(1);
});
