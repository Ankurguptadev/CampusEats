-- CS543 Tutorial 7: Campus Library database
CREATE DATABASE IF NOT EXISTS library;
USE library;

CREATE TABLE IF NOT EXISTS authors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    country VARCHAR(50) DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    year INT DEFAULT NULL,
    author_id INT NOT NULL,
    CONSTRAINT fk_books_author
        FOREIGN KEY (author_id) REFERENCES authors(id)
);

-- Insert sample authors only if they do not already exist.
INSERT INTO authors (name, country)
SELECT 'Asha Patel', 'India'
WHERE NOT EXISTS (
    SELECT 1 FROM authors WHERE LOWER(name) = LOWER('Asha Patel')
);

INSERT INTO authors (name, country)
SELECT 'Ravi Kumar', 'India'
WHERE NOT EXISTS (
    SELECT 1 FROM authors WHERE LOWER(name) = LOWER('Ravi Kumar')
);

-- Insert sample books only if they do not already exist.
INSERT INTO books (title, year, author_id)
SELECT 'Databases 101', 2020, a.id
FROM authors a
WHERE LOWER(a.name) = LOWER('Asha Patel')
  AND NOT EXISTS (
      SELECT 1 FROM books b
      WHERE b.title = 'Databases 101' AND b.author_id = a.id
  );

INSERT INTO books (title, year, author_id)
SELECT 'SQL in Practice', 2022, a.id
FROM authors a
WHERE LOWER(a.name) = LOWER('Asha Patel')
  AND NOT EXISTS (
      SELECT 1 FROM books b
      WHERE b.title = 'SQL in Practice' AND b.author_id = a.id
  );

INSERT INTO books (title, year, author_id)
SELECT 'Web Services Basics', 2023, a.id
FROM authors a
WHERE LOWER(a.name) = LOWER('Ravi Kumar')
  AND NOT EXISTS (
      SELECT 1 FROM books b
      WHERE b.title = 'Web Services Basics' AND b.author_id = a.id
  );
