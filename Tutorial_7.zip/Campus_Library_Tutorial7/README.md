# Campus Library — CS543 Tutorial 7

**Student:** Pintu  
**Roll No.:** 20252651038  
**Course:** CS543 — Web Services

A Campus Library web application built using HTML, CSS, JavaScript, Node.js, Apollo Server, GraphQL and MySQL. It displays authors with their books and allows users to add a book through a GraphQL mutation.

## 1. Requirements

- Node.js v20 or newer
- MySQL Community Server
- VS Code
- Live Server extension in VS Code

Check the installations:

```bash
node -v
npm -v
mysql --version
```

## 2. Open the project

Extract the ZIP file and open the `Campus_Library_Tutorial7` folder in VS Code.

## 3. Create the MySQL database

Open a terminal and run:

```bash
mysql -u root -p
```

After entering your MySQL password, run the SQL file from the project folder:

```sql
SOURCE schema.sql;
```

If MySQL cannot locate the file, provide its full path, for example:

```sql
SOURCE C:/path/to/Campus_Library_Tutorial7/schema.sql;
```

Verify the sample data:

```sql
USE library;
SELECT * FROM authors;
SELECT * FROM books;
```

The schema uses `CREATE TABLE IF NOT EXISTS` and inserts sample records only when they are missing. It does not drop existing tables.

## 4. Configure the database password

Copy `.env.example` and rename the copy to `.env`.

On Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Open `.env` and replace `YOUR_MYSQL_PASSWORD` with your own MySQL password. Do not share or upload the `.env` file.

## 5. Install Node.js packages

In the project root terminal:

```bash
npm install
```

This installs Apollo Server, GraphQL, MySQL2 and dotenv.

## 6. Start the GraphQL API

```bash
npm start
```

Expected message:

```text
GraphQL API ready at http://localhost:3000/
```

Keep this terminal running.

Open `http://localhost:3000/` in a browser to access Apollo Sandbox and test GraphQL operations.

## 7. Test the GraphQL query

Run this query in Apollo Sandbox:

```graphql
query {
  authors {
    id
    name
    country
    books {
      id
      title
      year
    }
  }
}
```

It returns each author and their books in one request.

## 8. Test the GraphQL mutation

This mutation adds a book. If the author name already exists, that author is reused. Otherwise, a new author is created.

```graphql
mutation {
  addBook(
    title: "GraphQL for Beginners"
    year: 2025
    authorName: "Ravi Kumar"
  ) {
    id
    title
    year
    author {
      id
      name
    }
  }
}
```

Verify the inserted record in MySQL:

```sql
USE library;
SELECT title, year, author_id FROM books;
```

## 9. Run the frontend

1. Open `public/index.html` in VS Code.
2. Right-click the file.
3. Select **Open with Live Server**.
4. The Campus Library page opens in the browser.
5. The page loads authors and books from the GraphQL API.
6. Use the form to add a book. Enter its title, author name and optional publication year.
7. After successful submission, the collection refreshes automatically.

Keep the Node.js API running while using the frontend.

## 10. Project structure

```text
Campus_Library_Tutorial7/
│
├── public/
│   ├── index.html
│   ├── style.css
│   └── script.js
│
├── .env.example
├── .gitignore
├── db.js
├── package.json
├── README.md
├── schema.sql
└── server.js
```

## 11. Concepts demonstrated

- **GraphQL schema:** Defines Author, Book, Query and Mutation types.
- **Query:** Reads authors, books and an individual author.
- **Resolver:** Connects GraphQL fields with SQL queries.
- **Relationship resolver:** Fetches books for an author and the author for a book.
- **Mutation:** Inserts a new book into MySQL.
- **Frontend:** Sends GraphQL requests using HTTP POST and displays the returned data.

## Conclusion

The Campus Library application connects a browser frontend to a GraphQL API built with Node.js and Apollo Server. The API communicates with MySQL to retrieve and insert author and book records. Thus, the tutorial demonstrates one complete read operation (query) and one write operation (mutation).
