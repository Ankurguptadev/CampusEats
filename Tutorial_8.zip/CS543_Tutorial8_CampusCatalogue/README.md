# CS543 Tutorial 8 — CampusEats Catalogue (Node + Express)

This project is prepared using the Campus Library Tutorial 7 ZIP as a base for its front-end style/structure, and follows the Node & Express REST API requirements in Tutorial 8.

## Features
- `GET /` — server health message
- `GET /items` — list all menu items (JSON)
- `GET /items/:id` — one item; returns `404` if not found
- `POST /items` — add an item; returns `201 Created`; validates name and price (`422` on invalid input)
- `DELETE /items/:id` — optional extension route (`204` on success)
- HTML/CSS frontend loads items with `fetch()` and adds dishes through a form.
- Data is held in memory; it resets after a server restart, as in Tutorial 8.

## Requirements
- Node.js v18 or newer
- npm

## Run
```bash
npm install
npm start
```
Open: http://localhost:3000

## Test API
```bash
curl localhost:3000/items
curl localhost:3000/items/1
curl -i localhost:3000/items/99
curl -i -X POST localhost:3000/items -H "Content-Type: application/json" -d '{"name":"Masala Dosa","price":60,"category":"Meals"}'
curl -i -X DELETE localhost:3000/items/1
```

## Project structure
```text
CS543_Tutorial8_CampusCatalogue/
├── server.js
├── package.json
├── README.md
└── public/
    ├── index.html
    ├── script.js
    └── style.css
```

## Note
This is a Tutorial 8 REST project, not the Tutorial 7 GraphQL/MySQL application. The menu array is intentionally in-memory.
