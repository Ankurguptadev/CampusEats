const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware: parse JSON bodies and serve the frontend
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// In-memory catalogue (data resets whenever the server restarts)
let items = [
  { id: 1, name: 'Veg Thali', price: 90, category: 'Meals' },
  { id: 2, name: 'Paneer Roll', price: 70, category: 'Snacks' },
  { id: 3, name: 'Masala Dosa', price: 60, category: 'Meals' }
];
let nextId = 4;

// GET / — health/check route
app.get('/', (req, res) => {
  res.send('CampusEats Catalogue is alive');
});

// GET /items — return the complete catalogue
app.get('/items', (req, res) => {
  res.json(items);
});

// GET /items/:id — return one item or 404
app.get('/items/:id', (req, res) => {
  const item = items.find((entry) => entry.id === Number(req.params.id));
  if (!item) return res.status(404).json({ error: 'Item not found' });
  res.json(item);
});

// POST /items — validate and create a new item
app.post('/items', (req, res) => {
  const { name, price, category } = req.body;

  if (typeof name !== 'string' || !name.trim()) {
    return res.status(422).json({ error: 'name required' });
  }

  const numericPrice = Number(price);
  if (price === undefined || price === '' || !Number.isFinite(numericPrice) || numericPrice < 0) {
    return res.status(422).json({ error: 'valid non-negative price required' });
  }

  const item = {
    id: nextId++,
    name: name.trim(),
    price: numericPrice,
    category: typeof category === 'string' && category.trim() ? category.trim() : 'Other'
  };

  items.push(item);
  res.status(201).json(item);
});

// Optional: DELETE /items/:id — remove an item (extension task)
app.delete('/items/:id', (req, res) => {
  const id = Number(req.params.id);
  const index = items.findIndex((entry) => entry.id === id);
  if (index === -1) return res.status(404).json({ error: 'Item not found' });
  items.splice(index, 1);
  res.status(204).send();
});

// Handle malformed JSON
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({ error: 'Invalid JSON body' });
  }
  next(err);
});

app.listen(PORT, () => {
  console.log(`CampusEats Catalogue running at http://localhost:${PORT}`);
});
