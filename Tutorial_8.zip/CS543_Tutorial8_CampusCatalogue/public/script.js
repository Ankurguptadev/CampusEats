const list = document.getElementById('list');
const summary = document.getElementById('summary');
const form = document.getElementById('addForm');
const formMessage = document.getElementById('formMessage');

function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
}

// READ: GET /items
async function loadItems() {
  list.innerHTML = '<div class="loading-card">Loading items...</div>';
  try {
    const response = await fetch('/items');
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const items = await response.json();

    summary.textContent = `${items.length} ${items.length === 1 ? 'dish' : 'dishes'} available`;
    if (!items.length) {
      list.innerHTML = '<div class="state-card"><h3>Catalogue is empty</h3><p>Add a dish to get started.</p></div>';
      return;
    }

    list.innerHTML = items.map(item => `
      <article class="item-card">
        <div class="item-top"><span class="category">${escapeHTML(item.category || 'Other')}</span><span class="item-id">#${item.id}</span></div>
        <h3>${escapeHTML(item.name)}</h3>
        <p class="price">₹${Number(item.price).toFixed(2).replace(/\.00$/, '')}</p>
      </article>
    `).join('');
  } catch (error) {
    summary.textContent = 'Could not load catalogue';
    list.innerHTML = `<div class="state-card"><h3>Unable to load items</h3><p>${escapeHTML(error.message)}</p><button id="retryButton" type="button">Try again</button></div>`;
    document.getElementById('retryButton')?.addEventListener('click', loadItems);
  }
}

// WRITE: POST /items
form.addEventListener('submit', async event => {
  event.preventDefault();
  const button = form.querySelector('button[type="submit"]');
  const name = document.getElementById('name').value.trim();
  const price = document.getElementById('price').value;
  const category = document.getElementById('category').value.trim();

  button.disabled = true;
  button.textContent = 'Adding dish...';
  formMessage.textContent = '';
  formMessage.className = 'form-message';

  try {
    const response = await fetch('/items', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, price, category })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || `HTTP ${response.status}`);

    form.reset();
    formMessage.textContent = `Added "${result.name}" successfully (ID ${result.id}).`;
    formMessage.className = 'form-message success';
    await loadItems();
  } catch (error) {
    formMessage.textContent = `Could not add dish: ${error.message}`;
    formMessage.className = 'form-message failure';
  } finally {
    button.disabled = false;
    button.innerHTML = '<span>Add to catalogue</span><span aria-hidden="true">→</span>';
  }
});

loadItems();
